//메뉴

    $(".nav > ul > li").hover(function(){
        $(this).find(".submenu").stop().slideDown();
    }, function(){
        $(this).find(".submenu").stop().slideUp();
    });

   //이미지 슬라이드
var slideCount = $(".slideImg").length;
//console.log(slideCount);
var currentIndex = 0;

setInterval(function(){
    if(currentIndex < slideCount - 1){
        currentIndex++
    }else{
        currentIndex = 0
    };
    var slidePosition = currentIndex * (-1000)+"px"
    $(".slideList").animate({left:slidePosition},300)
},4000)

//탭메뉴 
var tabBtn = $(".tab-btn > ul > li");
var tabCont = $(".tab-cont > div");

tabCont.hide().eq(0).show();

tabBtn.click(function(e){
    e.preventDefault();
    var target = $(this);
    var index = target.index();
//    alert(index)
    tabBtn.removeClass("active");
    target.addClass("active");
    tabCont.css("display","none");
    tabCont.eq(index).css("display","block");
});



//레이어 팝업
$("#content1 .right").click(function(){
    $(".layer").slideDown(300)
    $(".layer_bg").show();
})
$(".layer .close").click(function(){
    $("layer").slideUp(300)
    $(".layer_bg").hide();
})
